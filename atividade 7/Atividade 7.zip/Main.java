/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Pessoa> pessoas = new ArrayList<>();
        Estudante e1 = new Estudante("Amelia", 20, "Feminino", "Fisica");
        Professor p1 = new Professor("Dr. Who", 50, "Masculino", "Fiica");
        
        pessoas.add(e1);
        pessoas.add(p1);
        
        for (Pessoa pessoa : pessoas) {
            pessoa.apresentar();
            pessoa.realizarAcao();
            System.out.println();
        }
        if (e1.getDisciplina().equals(p1.getDisciplina())) {
            System.out.println(p1.getNome() + " está dando aula para " + e1.getNome() + ".");
        }else {
            System.out.println(p1.getNome() + " não está dando aula para " + e1.getNome() + ".");
        }
    }
}